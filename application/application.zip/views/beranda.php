<?php $this->load->view('tema/Header', $title); ?>

<!-- ======================================================== conten ======================================================= -->
<!-- Content Wrapper. Contains page content -->
<!-- <div class="content-wrapper"> -->
<div class="content-header">
	<div class="row justify-content-center">
		<div class="card-header">
			<div class="col-12">
				<img src="<?= base_url('asset/img/crepe_logo.png'); ?>" width="400">
			</div>
		</div>
	</div>
</div>

<!-- ======================================================== conten ======================================================= -->

<!-- ======================================================== conten ======================================================= -->



<?php $this->load->view('tema/Footer'); ?>