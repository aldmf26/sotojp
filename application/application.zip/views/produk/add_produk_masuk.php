<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-8">
                
            </div>
        </div>
    </div>
</div>